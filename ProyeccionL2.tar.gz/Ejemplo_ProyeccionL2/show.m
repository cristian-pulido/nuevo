function show(T,P,U)
%  T  matriz de conectividad  elementos #matriz triangulos
%  P  matriz de coordenadas de los nodos 
%  U  Funci�n a graficar sobre la malla de elemetos finitos

trisurf(T,P(:,1),P(:,2),U','facecolor','interp')
view(10,40);
title('Proyecci�n en L^2')