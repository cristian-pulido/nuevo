function M = ensambleMasa2D(p,t)
  np = size(p,2); % numero de nodos
  nt = size(t,2); % numero de elementos
  M = sparse(np,np); %  inicializaci�n de la matriz de masa 
for K = 1:nt %  bucle sobre los elementos 
    loc2glb = t(1:3,K); % transformaci�n de local-a-global 
    x = p(1,loc2glb); % coordenadas x del nodo 
    y = p(2,loc2glb); % coordenadas y del nodo 
    area = polyarea(x,y); % �rea del tri�ngulo 
    MK = [2 1 1; 1 2 1; 1 1 2]/12*area; %  Matriz de masa en el elemento 
    M(loc2glb,loc2glb) = M(loc2glb,loc2glb) + MK; % Sumando elementos a la matriz M
end
% p matriz que contiene las coordenadas de los nodos (np filas, 2 columnas)  o (2 filas, np columnas)
% t matriz que contiene los vertices de los triangulos k_i de la malla de tamaño (nt: # triangulos, 3 nodos) o al contrario
