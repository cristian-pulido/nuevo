function L2Proyeccion2D()
% Si usa MATLAB con el PDEtool puede utilizar las sgte instruccions
%g = Rectg(0,0,1,1); % cuadrado unitario
%[p,e,t] = initmesh(g,�hmax�,0.1); % cree la malla


% Usando Distmesh 
fd=@(p) drectangle(p,0,1,0,1); % cuadrado unitario
[p,t]=distmesh2d(fd,@huniform,0.1,[0,0;1,1],[0,0;1,0;0,1;1,1]); % cree la malla

M = ensambleMasa2D(p',t'); %  ensamble matiz de masa 
b = ensambleCarga2D(p',t',@Foo2); % ensamble vector de v�carga
Pf = M\b; % Solucion del sistema lineal
figure
show(t,p,full(Pf)); % Dibuje la proyeccion 


% pdesurf(p',t',Pf) % Dibuje la proyeccion usando Matlab con pdetool