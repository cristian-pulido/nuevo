function f = Foo2(x, y)
f = x.^3.*(1-y);