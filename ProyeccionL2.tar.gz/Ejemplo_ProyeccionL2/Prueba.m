range = linspace (0, 1, 20);
[X, Y] = meshgrid (range, range);
Z = Foo2 (X, Y);
figure
 surf (X, Y, Z);